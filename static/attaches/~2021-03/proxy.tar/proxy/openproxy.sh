# wsl2 需要先获取宿主机 ip
# export WINDOWS_IP=$(ip route | grep default | awk '{print $3}');
# wsl1 可以直接访问宿主机 127.0.0.1
export WINDOWS_IP='192.168.32.1';
# 设置 http 代理
export {http_proxy,https_proxy,HTTP_PROXY,HTTPS_PROXY}=http://$WINDOWS_IP:7890;
# 设置 socks 代理
export {all_proxy,ALL_PROXY}=socks5://$WINDOWS_IP:7890;

echo $http_proxy
